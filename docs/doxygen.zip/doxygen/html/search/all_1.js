var searchData=
[
  ['_5ffooter_2ephp_0',['_footer.php',['../__footer_8php.html',1,'']]],
  ['_5fheader_2ephp_1',['_header.php',['../__header_8php.html',1,'']]]
];
