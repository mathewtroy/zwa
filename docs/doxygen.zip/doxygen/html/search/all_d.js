var searchData=
[
  ['package_2ephp_0',['package.php',['../package_8php.html',1,'']]],
  ['paste_5fcomments_2ephp_1',['paste_comments.php',['../paste__comments_8php.html',1,'']]],
  ['privacy_2ephp_2',['privacy.php',['../privacy_8php.html',1,'']]]
];
